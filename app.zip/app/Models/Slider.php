<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\Model;

class Slider extends Model
{
    protected $table = 'slider';
}
